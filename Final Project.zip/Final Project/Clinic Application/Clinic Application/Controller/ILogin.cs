﻿using Clinic_Application.Model;

namespace Clinic_Application.Controller
{
    public interface ILogin
    {
        public Task<user_login_tbl?> LoginDetails(user_login_tbl LoginDetails);
    }
}
