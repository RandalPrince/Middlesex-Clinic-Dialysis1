﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Clinic_Application.Model
{
    public class patients_tbl
    {
        [Key]
        [MaxLength(11)]
        
        public int Patient_TRN_Number { get; set; }

        [Column(TypeName ="varchar")]
        [Required(ErrorMessage ="First name field required.")]
        [MaxLength(30)]
        [DataType(DataType.Text)]
        public string First_Name { get; set; }

        [Column(TypeName = "varchar")]
        [Required(ErrorMessage = "Last name field required.")]
        [MaxLength(30)]
        public string Last_Name { get; set; }

        [Required(ErrorMessage ="Gender required.")]
        [MaxLength(10)]
        public string Gender { get; set; }

        [Required]
        [MaxLength(11)]
        [Column(TypeName ="int")]
        
        public int? Age { get; set; }

        [Column(TypeName = "varchar")]
        [Required(ErrorMessage = "Street field required.")]
        [MaxLength(255)]
        public string Street { get; set; }

        [Column(TypeName = "varchar")]
        [Required(ErrorMessage = "Parish field required.")]
        [MaxLength(15)]
        public string Parish { get; set; }

        public user_login_tbl? user_login_tbl { get; set; }

    }
}
