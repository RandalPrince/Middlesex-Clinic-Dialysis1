﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Clinic_Application.Model
{
    public class user_role_tbl
    {
        [Key]
        [MaxLength(11)]
        public int User_ID { get; set; }

        [Required(ErrorMessage ="Most have a username")]
        [Column(TypeName ="varchar")]
        [MaxLength(25)]
        public string Username { get; set; }
    }
}
