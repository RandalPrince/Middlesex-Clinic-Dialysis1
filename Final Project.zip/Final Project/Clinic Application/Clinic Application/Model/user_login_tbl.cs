﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Clinic_Application.Model
{
    [Index(nameof(Username),IsUnique =true)]
    public class user_login_tbl
    {
		public user_login_tbl()
		{

		}
        [Key]
        [MaxLength(11)]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int User_ID { get; set; }

        [Required]
        [Column(TypeName ="varchar")]
        [MaxLength(20)]
        public string Username { get; set; }

        [Required]
        [MaxLength(25)]
        [Column(TypeName ="varchar")]
        [DataType(DataType.Password)]
        
        public string UPassword { get; set; }
        
        //Foreign key
        [Column(TypeName ="int")]
        [MaxLength(11)]
        
        public int? Patient_TRN_Number { get; set; }

        //Foreign key
        [Column(TypeName = "int")]
        [MaxLength(11)]
        
        public int? DoctorID { get; set; }

        [ForeignKey("Patient_TRN_Number")]
        public virtual patients_tbl? patients_tbl { get; set; }
        [ForeignKey("DoctorID")]
        public virtual doctor_tbl? doctor_tbl { get; set; }
    }
}
