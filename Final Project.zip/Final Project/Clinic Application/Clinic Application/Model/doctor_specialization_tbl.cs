﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Clinic_Application.Model
{
    public class doctor_specialization_tbl
    {
        [Key]
        [MaxLength(11)]
        public int SpecializationID { get; set; }

        [Required]
        [Column(TypeName ="Varchar")]
        [MaxLength(150)]
        public string Specialization_Name { get; set; }
    }
}
