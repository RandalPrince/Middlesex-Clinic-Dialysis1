﻿using Clinic_Application.Model;
using Microsoft.EntityFrameworkCore;

namespace Clinic_Application.Data
{
    public class ClinicContext : DbContext
    {
        public doctor_tbl Doc { get; set; } = new doctor_tbl();
        public user_login_tbl Login { get; set; } = new user_login_tbl();

        public doctor_tbl Doc2 { get; set; } = new doctor_tbl();
        public user_login_tbl Login2 { get; set; } = new user_login_tbl();
        public ClinicContext()
        {
            //Database.EnsureCreated();
            
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySql(
                "server=localhost;user=root_admin;port=3307;password=Test@000;database=clinicdb;",
                new MySqlServerVersion(new Version(8, 0, 11))
            );
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<doctor_tbl>().HasData
                (
                    
                    new doctor_tbl
                    {
                        DoctorID=1,
                        
                        First_Name="Jon",
                        Last_Name="Doh",
                        TRN_Number=1234141,
                        Gender="Male",
                    },
                    new doctor_tbl
                    {
                        DoctorID = 2,

                        First_Name = "Mic",
                        Last_Name = "dog",
                        TRN_Number = 1234141,
                        Gender = "Female",
                    }

                );

            modelBuilder.Entity<user_login_tbl>().HasData
                (

                    new user_login_tbl
                    {
                        User_ID=1,
                        Username="User",
                        UPassword="1234",
                        DoctorID=1
                    },
                    new user_login_tbl
                    {
                        User_ID = 2,
                        Username = "User2",
                        UPassword = "123456",
                        DoctorID = 2
                    }

                );

            modelBuilder.Entity<patients_tbl>().HasData
                (

                    new patients_tbl
                    {
                        Patient_TRN_Number=1,
                        First_Name="Jonathan",
                        Last_Name="Williams",
                        Gender="Male",
                        Age=30,
                        Parish="St.Andrew",
                        Street="StonyHill",
                        
                    },
                    new patients_tbl
                    {
                        Patient_TRN_Number = 2,
                        First_Name = "Michael",
                        Last_Name = "Smith",
                        Gender = "Male",
                        Age = 30,
                        Parish = "St.Thomas",
                        Street = "10 miles",

                    }

                );
            modelBuilder.Entity<user_login_tbl>().HasData
                (

                    new user_login_tbl
                    {
                        User_ID = 3,
                        Username = "User3",
                        UPassword = "1234",
                        Patient_TRN_Number = 1,
                        DoctorID = null,

                    },
                    new user_login_tbl
                    {
                        User_ID = 4,
                        Username = "User4",
                        UPassword = "1234",
                        Patient_TRN_Number = 2,
                        DoctorID = null,
                        

                    }

                );
            
        }

        public DbSet<appointments_status_tbl> appointments_status_tbl { get; set; }
        public DbSet<appointments_tbl> appointments_tbl { get; set; }
        public DbSet<doctor_specialization_tbl> doctor_specialization_tbl { get; set; }
        public DbSet<doctor_tbl> doctor_tbl { get; set; }
        public DbSet<patients_tbl> patients_tbl { get; set; }
        public DbSet<user_login_tbl> user_login_tbl { get; set; }
        public DbSet<user_role_tbl> user_role_tbl { get; set; }
    }
}
